"""
Generative branch inference with FULL VISUALIZATION.

Every attempt saves to viz_dir:
  attempt1_prior_map.png              structural prior map from SFA->RFR
  attempt1_step_000.png ...           x0 estimate at each viz step - watch
                                      the damaged region form progressively
  attempt1_result.png                 feathered composite
  attempt1_binary.png                 binarized image fed to ZXing

deps: pip install diffusers torch opencv-python-headless zxing-cpp
"""

import argparse
import os

import cv2
import numpy as np
import torch
from diffusers import DDIMScheduler

from train import RecoveryNet

IMG = 256


# ----------------------------- pre / post processing -----------------------------

def load_gray(path):
    img = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
    if img is None:
        raise FileNotFoundError(path)
    return cv2.resize(img, (IMG, IMG), interpolation=cv2.INTER_AREA)


def to_tensor(arr, device):
    return (torch.from_numpy(arr.astype(np.float32) / 127.5 - 1.0)
            .unsqueeze(0).unsqueeze(0).to(device))


def to_uint8(t):
    arr = ((t.squeeze().clamp(-1, 1).cpu().numpy() + 1.0) * 127.5)
    return arr.astype(np.uint8)


def feather_composite(restored, original, mask, radius=2):
    m = cv2.GaussianBlur(mask.astype(np.float32), (0, 0), radius)
    m = np.clip(m, 0, 1)
    out = restored.astype(np.float32) * m + original.astype(np.float32) * (1 - m)
    return out.astype(np.uint8)


def binarize(img):
    return cv2.adaptiveThreshold(img, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                 cv2.THRESH_BINARY, 31, 5)


def try_decode(img):
    import zxingcpp
    res = zxingcpp.read_barcode(img)
    if res is not None and res.valid:
        return res.text
    return None


def mask_overlay(image, mask):
    """Red overlay of detected damage on the input - for visualization."""
    rgb = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
    red = rgb.copy()
    red[mask > 0] = (0, 0, 255)
    return cv2.addWeighted(rgb, 0.6, red, 0.4, 0)


# ----------------------------- diffusion inpainting -----------------------------

@torch.no_grad()
def inpaint_once(unet, scheduler, damaged_t, mask_t, prior_map, steps=50,
                 seed=None, device="cuda", viz_dir=None, viz_every=5, tag=""):
    """One masked inpainting sample. If viz_dir is set, saves the model's
    x0 estimate every `viz_every` steps: the known region is pasted in, so
    the frames show ONLY the damaged region being generated."""
    g = torch.Generator(device=device)
    if seed is not None:
        g.manual_seed(seed)

    known = damaged_t * (1 - mask_t)
    cond = torch.cat([known, mask_t, prior_map], dim=1)

    scheduler.set_timesteps(steps, device=device)
    x = torch.randn(damaged_t.shape, generator=g, device=device)

    for i, t in enumerate(scheduler.timesteps):
        out = scheduler.step(unet(torch.cat([x, cond], dim=1), t).sample, t, x)
        x = out.prev_sample

        if viz_dir and (i % viz_every == 0 or i == len(scheduler.timesteps) - 1):
            # x0 estimate: generated hole + true known pixels
            x0_est = out.pred_original_sample
            frame = mask_t * x0_est + (1 - mask_t) * damaged_t
            cv2.imwrite(os.path.join(viz_dir, f"{tag}step_{i:03d}.png"),
                        to_uint8(frame))

        prev_i = i + 1
        if prev_i < len(scheduler.timesteps):
            t_prev = scheduler.timesteps[prev_i]
            noise = torch.randn(x.shape, generator=g, device=device)
            known_noisy = scheduler.add_noise(damaged_t, noise,
                                              t_prev.unsqueeze(0))
            x = mask_t * x + (1 - mask_t) * known_noisy
        else:
            x = mask_t * x + (1 - mask_t) * damaged_t

    return x


# ----------------------------- decode-verify feedback loop -----------------------------

@torch.no_grad()
def recover(net, scheduler, damaged, mask, k=5, steps=50, base_rfr_iters=4,
            perturb_step=0.15, device="cuda", viz_dir=None, viz_every=5):
    """Decode failure feeds back into RFR (more iters + perturbed hidden
    state) -> new prior map -> rediffusion. Saves full viz per attempt."""
    damaged_t = to_tensor(damaged, device)
    mask_np = (mask > 0)
    mask_t = (torch.from_numpy(mask_np.astype(np.float32))
              .unsqueeze(0).unsqueeze(0).to(device))
    if viz_dir:
        os.makedirs(viz_dir, exist_ok=True)

    best = None
    for attempt in range(k):
        tag = f"attempt{attempt+1}_"
        prior_map = net.prior(damaged_t, mask_t,
                              rfr_iters=base_rfr_iters + attempt,
                              perturb=perturb_step * attempt)
        if viz_dir:
            cv2.imwrite(os.path.join(viz_dir, f"{tag}prior_map.png"),
                        to_uint8(prior_map))

        x0 = inpaint_once(net.unet, scheduler, damaged_t, mask_t, prior_map,
                          steps=steps, seed=attempt, device=device,
                          viz_dir=viz_dir, viz_every=viz_every, tag=tag)
        restored = feather_composite(to_uint8(x0), damaged, mask_np)
        binary = binarize(restored)
        best = restored if best is None else best

        if viz_dir:
            cv2.imwrite(os.path.join(viz_dir, f"{tag}result.png"), restored)
            cv2.imwrite(os.path.join(viz_dir, f"{tag}binary.png"), binary)

        text = try_decode(binary) or try_decode(restored)
        if text is not None:
            return text, restored, attempt + 1
    return None, best, k


# ----------------------------- cli -----------------------------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True, help="path to final.pt")
    ap.add_argument("--image", required=True)
    ap.add_argument("--mask", required=True, help="mask png (white=damaged)")
    ap.add_argument("--k", type=int, default=5)
    ap.add_argument("--steps", type=int, default=50)
    ap.add_argument("--viz_dir", default="viz")
    ap.add_argument("--out", default="restored.png")
    args = ap.parse_args()

    device = "cuda" if torch.cuda.is_available() else "cpu"
    net = RecoveryNet().to(device).eval()
    net.load_state_dict(torch.load(args.ckpt, map_location=device))
    scheduler = DDIMScheduler(num_train_timesteps=1000,
                              beta_schedule="squaredcos_cap_v2",
                              prediction_type="v_prediction")

    damaged = load_gray(args.image)
    mask = load_gray(args.mask)
    os.makedirs(args.viz_dir, exist_ok=True)
    cv2.imwrite(os.path.join(args.viz_dir, "00_input.png"), damaged)
    cv2.imwrite(os.path.join(args.viz_dir, "00_mask_overlay.png"),
                mask_overlay(damaged, mask))

    text, restored, n = recover(net, scheduler, damaged, mask, k=args.k,
                                steps=args.steps, device=device,
                                viz_dir=args.viz_dir)
    cv2.imwrite(args.out, restored)
    print(f"viz saved to {args.viz_dir}/")
    print(f"DECODED after {n} attempt(s): {text}" if text
          else f"FAILED after {n} attempts. See {args.out}")


if __name__ == "__main__":
    main()
