# Damaged Barcode Recovery - Complete Pipeline

Architecture (paper diagram):

    damaged photo
      [1] DamageUNet          -> predicted damage mask (1.9M params)
      [2] fast-path decode    -> if ZXing already reads it, done
      [3] StructuralPriorNet  -> SFA -> RFR -> structural prior map (1.7M)
      [4] Diffusion UNet      -> masked pixel-space inpainting (22M),
                                 known region hard-constrained
      [5] binarize -> ZXing decode (Reed-Solomon verify)
            valid   -> output
            invalid -> FEEDBACK: RFR re-runs with +1 iteration and
                       perturbed hidden state -> new prior map -> rediffuse

## Install
    pip install torch diffusers accelerate qrcode python-barcode pillow \
                opencv-python-headless zxing-cpp

## Data layout (your 10k pairs)
    DATA/clean/xxx.png
    DATA/damaged/xxx.png      (matching filenames)
Masks are derived automatically: |clean - damaged| threshold + morphology.
Last 500 pairs are auto-held-out for eval.

## RUN SEQUENCE (one A6000, overnight)

STEP 0 - sanity-check derived masks BEFORE any long run (~1 min):
    python -c "from data import RealPairs; import cv2; \
      rp = RealPairs('DATA'); \
      [cv2.imwrite(f'maskcheck_{i}.png', s['mask'].numpy()[0]*255) \
       for i, s in zip(range(10), rp)]"
    -> eyeball maskcheck_*.png. If masks look wrong, your pairs are not
       pixel-aligned; fix alignment before training.

STEP 1 - train the damage detector (~1.5h):
    python damage_detector.py train --real_dir DATA --steps 20000 --batch 64

STEP 2 - train prior net + diffusion jointly (~6-7h):
    python train.py --real_dir DATA --steps 80000 --batch 32
    (decodable samples typically by ~30k steps: ckpt/step_30000.pt)

STEP 3 - eval table (~30 min):
    python eval.py --ckpt ckpt/final.pt --n 300 --k 3 --steps 30

STEP 4 - single-image demo with FULL visualization:
    python pipeline.py --detector ckpt/detector.pt --ckpt ckpt/final.pt \
                       --image some_damaged_photo.png

(If you already have a ground-truth mask and want to skip the detector:
    python infer.py --ckpt ckpt/final.pt --image d.png --mask m.png)

## Visualization output (viz/ folder, per run)
    00_input.png             damaged input
    01_predicted_mask.png    raw detector mask
    01_mask_overlay.png      damage painted red over the input
    attemptN_prior_map.png   SFA->RFR structural prior map, per attempt
    attemptN_step_XXX.png    the damaged region forming step by step
                             (known pixels pasted in, so ONLY the broken
                             region changes across frames)
    attemptN_result.png      feathered composite of attempt N
    attemptN_binary.png      the binarized image ZXing actually decodes
Control frame frequency with --viz_every (default 5).

## Verified in sandbox
- clean synthetic targets decode 40/40 (Code128 render bug found + fixed)
- derived-mask path on paired data works (shapes, fractions)
- prior net grads flow; perturb/iters provably change the prior map
- inpaint loop preserves known region exactly
- full viz flow produces all files listed above

## Paper notes
- Ablate feedback loop vs blind best-of-k (perturb_step=0, fixed iters).
- Report decode success vs damage fraction with RS capacity lines
  (L/M/Q/H = 7/15/25/30% of codewords).
- attemptN_step frames make a great qualitative figure.
