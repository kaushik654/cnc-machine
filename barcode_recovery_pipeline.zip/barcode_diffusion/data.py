"""
Synthetic damaged-barcode dataset for masked diffusion inpainting.
Generates (clean, damaged, mask) triplets on the fly - infinite data, no disk.

deps: pip install qrcode[pil] python-barcode segno opencv-python-headless numpy torch
"""

import io
import random
import string

import cv2
import numpy as np
import torch
from torch.utils.data import IterableDataset

IMG = 256  # working resolution


# ----------------------------- clean barcode rendering -----------------------------

def _rand_payload(n_min=8, n_max=40):
    n = random.randint(n_min, n_max)
    chars = string.ascii_letters + string.digits + ":/._-"
    return "".join(random.choices(chars, k=n))


def render_qr():
    import qrcode
    ec = random.choice([
        qrcode.constants.ERROR_CORRECT_L,
        qrcode.constants.ERROR_CORRECT_M,
        qrcode.constants.ERROR_CORRECT_Q,
        qrcode.constants.ERROR_CORRECT_H,
    ])
    qr = qrcode.QRCode(
        version=None, error_correction=ec,
        box_size=random.randint(6, 10),
        border=random.randint(2, 4),
    )
    payload = _rand_payload()
    qr.add_data(payload)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white").convert("L")
    return np.array(img), payload


def render_code128():
    from barcode import Code128
    from barcode.writer import ImageWriter
    payload = _rand_payload(4, 10)
    buf = io.BytesIO()
    Code128(payload, writer=ImageWriter()).write(
        buf, options={"write_text": False,
                      "module_width": 0.2,
                      "module_height": random.uniform(10, 16),
                      "quiet_zone": 2.0}
    )
    buf.seek(0)
    from PIL import Image
    img = Image.open(buf).convert("L")
    return np.array(img), payload


def _decodes(canvas, payload):
    try:
        import zxingcpp
        r = zxingcpp.read_barcode(canvas)
        return r is not None and r.valid and r.text == payload
    except ImportError:        # allow data gen without zxing installed
        return True


def _compose(arr):
    h, w = arr.shape
    scale = min(IMG / h, IMG / w)
    nh, nw = int(h * scale), int(w * scale)
    arr = cv2.resize(arr, (nw, nh), interpolation=cv2.INTER_NEAREST)
    canvas = np.full((IMG, IMG), 255, np.uint8)
    y, x = (IMG - nh) // 2, (IMG - nw) // 2
    canvas[y:y + nh, x:x + nw] = arr
    return canvas


def render_clean():
    """Random symbology -> 256x256 uint8. GUARANTEED decodable:
    a training target that zxing can't read would poison the eval."""
    for _ in range(5):
        fn = random.choices([render_qr, render_code128], weights=[0.7, 0.3])[0]
        arr, payload = fn()
        canvas = _compose(arr)
        if _decodes(canvas, payload):
            return canvas, payload
    arr, payload = render_qr()          # QR at 256px always decodes
    return _compose(arr), payload


# ----------------------------- damage mask synthesis -----------------------------

def mask_blob():
    noise = np.random.rand(IMG // 8, IMG // 8).astype(np.float32)
    noise = cv2.resize(noise, (IMG, IMG), interpolation=cv2.INTER_CUBIC)
    noise = cv2.GaussianBlur(noise, (31, 31), 0)
    thresh = np.quantile(noise, random.uniform(0.75, 0.93))
    return (noise > thresh).astype(np.uint8)


def mask_scratches():
    m = np.zeros((IMG, IMG), np.uint8)
    for _ in range(random.randint(1, 4)):
        pts = np.array([
            [random.randint(0, IMG), random.randint(0, IMG)] for _ in range(4)
        ], np.int32)
        # crude bezier via polyline through interpolated control points
        t = np.linspace(0, 1, 60)[:, None]
        curve = ((1 - t) ** 3 * pts[0] + 3 * (1 - t) ** 2 * t * pts[1]
                 + 3 * (1 - t) * t ** 2 * pts[2] + t ** 3 * pts[3]).astype(np.int32)
        cv2.polylines(m, [curve], False, 1, thickness=random.randint(3, 9))
    return m


def mask_rect():
    m = np.zeros((IMG, IMG), np.uint8)
    for _ in range(random.randint(1, 2)):
        w, h = random.randint(30, 110), random.randint(30, 110)
        x, y = random.randint(0, IMG - w), random.randint(0, IMG - h)
        ang = random.uniform(-30, 30)
        box = cv2.boxPoints(((x + w / 2, y + h / 2), (w, h), ang)).astype(np.int32)
        cv2.fillPoly(m, [box], 1)
    return m


def mask_corner():
    m = np.zeros((IMG, IMG), np.uint8)
    c = random.choice([(0, 0), (0, IMG), (IMG, 0), (IMG, IMG)])
    r = random.randint(50, 120)
    cv2.circle(m, c, r, 1, -1)
    return m


def make_mask():
    fns = random.sample([mask_blob, mask_scratches, mask_rect, mask_corner],
                        k=random.randint(1, 2))
    m = np.zeros((IMG, IMG), np.uint8)
    for f in fns:
        m |= f()
    frac = m.mean()
    if frac < 0.03 or frac > 0.45:   # keep damage in a learnable range
        return make_mask()
    return m


# ----------------------------- damage compositing -----------------------------

def apply_damage(clean, mask):
    fill_mode = random.random()
    if fill_mode < 0.35:                      # white-out (torn label / sticker)
        tex = np.full_like(clean, random.randint(220, 255))
    elif fill_mode < 0.6:                     # black-out (marker / dirt)
        tex = np.full_like(clean, random.randint(0, 40))
    elif fill_mode < 0.85:                    # paper-ish texture
        tex = np.clip(np.random.normal(200, 25, clean.shape), 0, 255).astype(np.uint8)
    else:                                     # smeared blur of original
        tex = cv2.GaussianBlur(clean, (21, 21), 0)
    damaged = np.where(mask == 1, tex, clean)
    # global photometric aug
    if random.random() < 0.5:
        damaged = cv2.GaussianBlur(damaged, (3, 3), 0)
    if random.random() < 0.5:
        damaged = np.clip(
            damaged.astype(np.float32) + np.random.normal(0, 6, damaged.shape),
            0, 255).astype(np.uint8)
    return damaged


# ----------------------------- torch dataset -----------------------------

def to_tensor(arr):
    """uint8 [0,255] -> float32 [-1,1], shape (1,H,W)"""
    return torch.from_numpy(arr.astype(np.float32) / 127.5 - 1.0).unsqueeze(0)


class DamagedBarcodes(IterableDataset):
    """Yields dict(clean, damaged, mask) - all (1,256,256) float tensors.
    mask is {0,1}; 1 = damaged region to inpaint."""

    def __iter__(self):
        while True:
            clean, _payload = render_clean()
            mask = make_mask()
            damaged = apply_damage(clean, mask)
            yield {
                "clean": to_tensor(clean),
                "damaged": to_tensor(damaged),
                "mask": torch.from_numpy(mask.astype(np.float32)).unsqueeze(0),
            }


if __name__ == "__main__":
    ds = iter(DamagedBarcodes())
    s = next(ds)
    print({k: (v.shape, v.min().item(), v.max().item()) for k, v in s.items()})


# ----------------------------- real paired data -----------------------------

import os
import glob


def derive_mask(clean, damaged, thresh=30, close_k=5, dilate_k=5):
    """Paired data -> free mask: threshold |clean - damaged|, then
    morphological close (fill pinholes) + dilate (over-mask is safe)."""
    diff = cv2.absdiff(clean, damaged)
    m = (diff > thresh).astype(np.uint8)
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((close_k, close_k), np.uint8))
    m = cv2.dilate(m, np.ones((dilate_k, dilate_k), np.uint8))
    return m


class RealPairs(IterableDataset):
    """Loops infinitely over real paired samples.
    Expects: root/clean/xxx.png + root/damaged/xxx.png (matching names)."""

    def __init__(self, root, split="train", holdout=500):
        files = sorted(os.path.basename(p) for p in
                       glob.glob(os.path.join(root, "clean", "*")))
        if not files:
            raise FileNotFoundError(f"no files in {root}/clean/")
        # deterministic split: last `holdout` files reserved for eval
        self.files = files[:-holdout] if split == "train" else files[-holdout:]
        self.root = root

    def load(self, name):
        c = cv2.imread(os.path.join(self.root, "clean", name), cv2.IMREAD_GRAYSCALE)
        d = cv2.imread(os.path.join(self.root, "damaged", name), cv2.IMREAD_GRAYSCALE)
        c = cv2.resize(c, (IMG, IMG), interpolation=cv2.INTER_AREA)
        d = cv2.resize(d, (IMG, IMG), interpolation=cv2.INTER_AREA)
        m = derive_mask(c, d)
        return c, d, m

    def __iter__(self):
        files = list(self.files)
        while True:
            random.shuffle(files)
            for name in files:
                try:
                    c, d, m = self.load(name)
                except Exception:
                    continue
                if m.mean() < 0.01:      # pair identical -> useless for inpainting
                    continue
                yield {
                    "clean": to_tensor(c),
                    "damaged": to_tensor(d),
                    "mask": torch.from_numpy(m.astype(np.float32)).unsqueeze(0),
                }


class MixedBarcodes(IterableDataset):
    """Sample real pairs with prob real_frac, else synthetic."""

    def __init__(self, real_root, real_frac=0.5):
        self.real_frac = real_frac
        self.real_root = real_root

    def __iter__(self):
        real = iter(RealPairs(self.real_root))
        synth = iter(DamagedBarcodes())
        while True:
            yield next(real) if random.random() < self.real_frac else next(synth)
