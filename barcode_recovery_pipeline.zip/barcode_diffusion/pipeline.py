"""
END-TO-END inference from ONLY a damaged barcode photo, fully visualized.

viz/ output:
  00_input.png            the damaged input
  01_predicted_mask.png   raw detector mask
  01_mask_overlay.png     mask painted red on the input
  attemptN_prior_map.png  SFA->RFR structural prior map per attempt
  attemptN_step_XXX.png   damaged region forming step by step
  attemptN_result.png     composite result per attempt
  attemptN_binary.png     what ZXing actually sees

run: python pipeline.py --detector ckpt/detector.pt --ckpt ckpt/final.pt \
                        --image damaged_photo.png
"""

import argparse
import os

import cv2
import torch
from diffusers import DDIMScheduler

from damage_detector import DamageUNet, predict_mask
from infer import binarize, load_gray, mask_overlay, recover, try_decode
from train import RecoveryNet


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--detector", required=True)
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--image", required=True)
    ap.add_argument("--k", type=int, default=5)
    ap.add_argument("--steps", type=int, default=50)
    ap.add_argument("--viz_dir", default="viz")
    ap.add_argument("--viz_every", type=int, default=5)
    ap.add_argument("--out", default="restored.png")
    args = ap.parse_args()

    device = "cuda" if torch.cuda.is_available() else "cpu"
    os.makedirs(args.viz_dir, exist_ok=True)

    damaged = load_gray(args.image)
    cv2.imwrite(os.path.join(args.viz_dir, "00_input.png"), damaged)

    # fast path of the cascade: decode as-is
    text = try_decode(binarize(damaged)) or try_decode(damaged)
    if text is not None:
        print(f"DECODED without restoration: {text}")
        return

    # stage 1: predict damage mask + visualize it
    det = DamageUNet().to(device).eval()
    det.load_state_dict(torch.load(args.detector, map_location=device))
    mask = predict_mask(det, damaged, device=device)
    cv2.imwrite(os.path.join(args.viz_dir, "01_predicted_mask.png"), mask * 255)
    cv2.imwrite(os.path.join(args.viz_dir, "01_mask_overlay.png"),
                mask_overlay(damaged, mask))
    print(f"damage detected: {mask.mean():.1%} of symbol "
          f"-> {args.viz_dir}/01_mask_overlay.png")

    # stages 2-6: prior -> diffusion (step frames saved) -> decode-verify loop
    net = RecoveryNet().to(device).eval()
    net.load_state_dict(torch.load(args.ckpt, map_location=device))
    scheduler = DDIMScheduler(num_train_timesteps=1000,
                              beta_schedule="squaredcos_cap_v2",
                              prediction_type="v_prediction")

    text, restored, n = recover(net, scheduler, damaged, mask, k=args.k,
                                steps=args.steps, device=device,
                                viz_dir=args.viz_dir, viz_every=args.viz_every)
    cv2.imwrite(args.out, restored)
    print(f"all visualizations -> {args.viz_dir}/")
    print(f"DECODED after {n} attempt(s): {text}" if text
          else f"FAILED after {n} attempts. Restored -> {args.out}")


if __name__ == "__main__":
    main()
