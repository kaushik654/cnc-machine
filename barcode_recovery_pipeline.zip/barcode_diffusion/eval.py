"""
Eval: decode success rate vs damage fraction, ours vs baselines.
Bins damage into 5-15 / 15-25 / 25-35 / 35-45 % of symbol area.

Baselines: raw zxing (no restoration), OpenCV Telea, OpenCV Navier-Stokes.
Extend with LaMa / pix2pix / RePaint rows for the paper table.

run: python eval.py --ckpt ckpt/final --n 500
"""

import argparse
from collections import defaultdict

import cv2
import numpy as np
import torch
from diffusers import DDIMScheduler
from train import RecoveryNet

from data import render_clean, make_mask, apply_damage
from infer import recover, binarize, try_decode

BINS = [(0.05, 0.15), (0.15, 0.25), (0.25, 0.35), (0.35, 0.45)]


def bin_of(frac):
    for lo, hi in BINS:
        if lo <= frac < hi:
            return f"{int(lo*100)}-{int(hi*100)}%"
    return None


def cv_inpaint(damaged, mask, flag):
    return cv2.inpaint(damaged, (mask * 255).astype(np.uint8), 5, flag)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--n", type=int, default=500)
    ap.add_argument("--k", type=int, default=5)
    ap.add_argument("--steps", type=int, default=50)
    args = ap.parse_args()

    device = "cuda" if torch.cuda.is_available() else "cpu"
    net = RecoveryNet().to(device).eval()
    net.load_state_dict(torch.load(args.ckpt, map_location=device))
    scheduler = DDIMScheduler(num_train_timesteps=1000,
                              beta_schedule="squaredcos_cap_v2",
                              prediction_type="v_prediction")

    hits = defaultdict(lambda: defaultdict(int))
    tot = defaultdict(int)

    done = 0
    while done < args.n:
        clean, payload = render_clean()
        mask = make_mask()
        b = bin_of(mask.mean())
        if b is None:
            continue
        damaged = apply_damage(clean, mask)
        tot[b] += 1
        done += 1

        # 1. raw decode, no restoration
        if try_decode(binarize(damaged)) == payload:
            hits[b]["raw"] += 1
        # 2. classical inpainting
        if try_decode(binarize(cv_inpaint(damaged, mask, cv2.INPAINT_TELEA))) == payload:
            hits[b]["telea"] += 1
        if try_decode(binarize(cv_inpaint(damaged, mask, cv2.INPAINT_NS))) == payload:
            hits[b]["navier"] += 1
        # 3. ours: diffusion inpaint + decode-verify k-resample
        text, _, _ = recover(net, scheduler, damaged, mask,
                             k=args.k, steps=args.steps, device=device)
        if text == payload:
            hits[b]["ours"] += 1

        if done % 25 == 0:
            print(f"[{done}/{args.n}]")

    methods = ["raw", "telea", "navier", "ours"]
    header = "damage    " + "".join(f"{m:>8}" for m in methods) + "       n"
    print("\n" + header)
    for lo, hi in BINS:
        b = f"{int(lo*100)}-{int(hi*100)}%"
        if tot[b] == 0:
            continue
        row = f"{b:<10}" + "".join(
            f"{hits[b][m]/tot[b]*100:7.1f}%" for m in methods) + f"{tot[b]:8d}"
        print(row)


if __name__ == "__main__":
    main()
