"""
Joint training: StructuralPriorNet (SFA -> RFR -> prior map) + diffusion UNet.

Conditioning channels: [x_t, damaged*(1-mask), mask, prior_map]  -> 4
Loss = mask-weighted v-prediction MSE  +  lambda * L1(prior_map, clean)
The aux L1 gives RFR a direct reconstruction target so the prior map
actually carries structure instead of collapsing.

deps: pip install diffusers accelerate torch
run : python train.py --steps 300000 --batch 64
"""

import argparse
import os

import torch
import torch.nn.functional as F
from diffusers import DDPMScheduler, UNet2DModel
from diffusers.training_utils import EMAModel
from torch.utils.data import DataLoader

from data import DamagedBarcodes, MixedBarcodes
from modules import StructuralPriorNet


def build_unet():
    return UNet2DModel(
        sample_size=256,
        in_channels=4,          # x_t, masked damaged, mask, prior map
        out_channels=1,
        layers_per_block=2,
        block_out_channels=(64, 128, 192, 256),
        down_block_types=("DownBlock2D", "DownBlock2D",
                          "AttnDownBlock2D", "AttnDownBlock2D"),
        up_block_types=("AttnUpBlock2D", "AttnUpBlock2D",
                        "UpBlock2D", "UpBlock2D"),
    )


class RecoveryNet(torch.nn.Module):
    """Prior net + diffusion UNet trained jointly."""

    def __init__(self):
        super().__init__()
        self.prior = StructuralPriorNet()
        self.unet = build_unet()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--steps", type=int, default=80_000)
    ap.add_argument("--real_dir", type=str, default=None)
    ap.add_argument("--real_frac", type=float, default=0.5)
    ap.add_argument("--batch", type=int, default=64)
    ap.add_argument("--lr", type=float, default=1e-4)
    ap.add_argument("--mask_loss_boost", type=float, default=4.0)
    ap.add_argument("--prior_l1_weight", type=float, default=0.5)
    ap.add_argument("--rfr_iters", type=int, default=4)
    ap.add_argument("--out", type=str, default="ckpt")
    ap.add_argument("--save_every", type=int, default=10_000)
    ap.add_argument("--workers", type=int, default=8)
    args = ap.parse_args()

    device = "cuda" if torch.cuda.is_available() else "cpu"
    dtype = torch.bfloat16 if device == "cuda" else torch.float32
    os.makedirs(args.out, exist_ok=True)

    net = RecoveryNet().to(device)
    n_prior = sum(p.numel() for p in net.prior.parameters())
    n_unet = sum(p.numel() for p in net.unet.parameters())
    print(f"prior {n_prior/1e6:.1f}M + unet {n_unet/1e6:.1f}M "
          f"= {(n_prior+n_unet)/1e6:.1f}M params")

    ema = EMAModel(net.parameters(), decay=0.9999)
    sched = DDPMScheduler(
        num_train_timesteps=1000,
        beta_schedule="squaredcos_cap_v2",
        prediction_type="v_prediction",
    )
    opt = torch.optim.AdamW(net.parameters(), lr=args.lr, weight_decay=1e-4)
    lr_sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=args.steps)

    ds = (MixedBarcodes(args.real_dir, args.real_frac)
          if args.real_dir else DamagedBarcodes())
    dl = DataLoader(ds, batch_size=args.batch,
                    num_workers=args.workers, pin_memory=True)

    net.train()
    step = 0
    for batch in dl:
        clean = batch["clean"].to(device)
        damaged = batch["damaged"].to(device)
        mask = batch["mask"].to(device)

        noise = torch.randn_like(clean)
        t = torch.randint(0, sched.config.num_train_timesteps,
                          (clean.shape[0],), device=device).long()
        x_t = sched.add_noise(clean, noise, t)
        target = sched.get_velocity(clean, noise, t)

        with torch.autocast(device_type=device, dtype=dtype, enabled=device == "cuda"):
            prior_map = net.prior(damaged, mask, rfr_iters=args.rfr_iters)
            net_in = torch.cat([x_t, damaged * (1 - mask), mask, prior_map], dim=1)
            pred = net.unet(net_in, t).sample

            w = 1.0 + args.mask_loss_boost * mask
            diff_loss = (w * F.mse_loss(pred, target, reduction="none")).mean()
            prior_loss = F.l1_loss(prior_map, clean)
            loss = diff_loss + args.prior_l1_weight * prior_loss

        opt.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(net.parameters(), 1.0)
        opt.step()
        lr_sched.step()
        ema.step(net.parameters())

        if step % 100 == 0:
            print(f"step {step:>7d}  loss {loss.item():.4f}  "
                  f"(diff {diff_loss.item():.4f} prior {prior_loss.item():.4f})  "
                  f"lr {lr_sched.get_last_lr()[0]:.2e}")

        if step % args.save_every == 0 and step > 0:
            ema.copy_to(net.parameters())
            torch.save(net.state_dict(), os.path.join(args.out, f"step_{step}.pt"))
            ema.restore(net.parameters())

        step += 1
        if step >= args.steps:
            break

    ema.copy_to(net.parameters())
    torch.save(net.state_dict(), os.path.join(args.out, "final.pt"))
    print("done ->", os.path.join(args.out, "final.pt"))


if __name__ == "__main__":
    main()
