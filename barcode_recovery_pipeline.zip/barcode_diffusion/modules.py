"""
Structural prior network: the paper-diagram stages before diffusion.

  damaged + mask
        |
  FeatureEncoder            (ResNet-style conv encoder -> 128ch @ 32x32)
        |
  StructuralFusionAttention (cross-attention with learned structural
        |                    tokens: finder/timing/grid priors)
  RecurrentFeatureReasoning (ConvGRU-style iterative hole filling,
        |                    partial-conv mask update, RFR-Net spirit)
  PriorMapHead              (upsample -> 1ch 256x256 structural prior map)
        |
  -> concatenated as 4th conditioning channel of the diffusion UNet

Feedback loop: on decode failure, RFR is re-run with more iterations and
a perturbed hidden state (see infer.py) - NOT a blind reseed.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F

FEAT_CH = 128
FEAT_RES = 32          # 256 / 8
N_STRUCT_TOKENS = 64   # learned structural prior tokens


# ----------------------------- feature encoder -----------------------------

class ConvBlock(nn.Module):
    def __init__(self, cin, cout, stride=1):
        super().__init__()
        self.conv = nn.Conv2d(cin, cout, 3, stride, 1)
        self.norm = nn.GroupNorm(8, cout)

    def forward(self, x):
        return F.silu(self.norm(self.conv(x)))


class FeatureEncoder(nn.Module):
    """(damaged, mask) 2ch @256 -> 128ch @32. Swap for ViT/ResNet later."""

    def __init__(self):
        super().__init__()
        self.net = nn.Sequential(
            ConvBlock(2, 32), ConvBlock(32, 32, stride=2),      # 128
            ConvBlock(32, 64), ConvBlock(64, 64, stride=2),     # 64
            ConvBlock(64, 128), ConvBlock(128, FEAT_CH, stride=2),  # 32
        )

    def forward(self, damaged, mask):
        return self.net(torch.cat([damaged, mask], dim=1))


# ----------------------------- structural fusion attention -----------------------------

class StructuralFusionAttention(nn.Module):
    """Image features cross-attend learned structural tokens that encode
    barcode priors (finder patterns, timing patterns, module grid).
    Tokens are learned end-to-end; positional embedding keeps the fusion
    spatially aware."""

    def __init__(self, dim=FEAT_CH, n_tokens=N_STRUCT_TOKENS, heads=4):
        super().__init__()
        self.struct_tokens = nn.Parameter(torch.randn(1, n_tokens, dim) * 0.02)
        self.pos = nn.Parameter(torch.randn(1, FEAT_RES * FEAT_RES, dim) * 0.02)
        self.attn = nn.MultiheadAttention(dim, heads, batch_first=True)
        self.norm1 = nn.LayerNorm(dim)
        self.norm2 = nn.LayerNorm(dim)
        self.ffn = nn.Sequential(
            nn.Linear(dim, dim * 4), nn.GELU(), nn.Linear(dim * 4, dim))

    def forward(self, feat):
        B, C, H, W = feat.shape
        x = feat.flatten(2).transpose(1, 2) + self.pos          # (B,HW,C)
        tok = self.struct_tokens.expand(B, -1, -1)
        a, _ = self.attn(self.norm1(x), tok, tok)
        x = x + a
        x = x + self.ffn(self.norm2(x))
        return x.transpose(1, 2).reshape(B, C, H, W)


# ----------------------------- recurrent feature reasoning -----------------------------

class RecurrentFeatureReasoning(nn.Module):
    """ConvGRU-style shared reasoning block applied T times.
    Each iteration: (1) update hidden features, (2) dilate the known
    region (partial-conv style mask update) so the hole is filled
    progressively from the boundary inward - the RFR-Net recurrence."""

    def __init__(self, dim=FEAT_CH):
        super().__init__()
        cin = dim * 2 + 1  # hidden + input features + mask
        self.convz = nn.Conv2d(cin, dim, 3, 1, 1)
        self.convr = nn.Conv2d(cin, dim, 3, 1, 1)
        self.convh = nn.Conv2d(cin, dim, 3, 1, 1)

    def step(self, h, x, m):
        inp = torch.cat([h, x, m], dim=1)
        z = torch.sigmoid(self.convz(inp))
        r = torch.sigmoid(self.convr(inp))
        h_tilde = torch.tanh(self.convh(torch.cat([r * h, x, m], dim=1)))
        return (1 - z) * h + z * h_tilde

    def forward(self, feat, mask_lr, iters=4, h_init=None, perturb=0.0):
        """feat: (B,C,32,32); mask_lr: (B,1,32,32) with 1 = hole.
        perturb > 0 injects noise into the initial hidden state - used by
        the decode-failure feedback loop to explore alternative fillings."""
        h = feat.clone() if h_init is None else h_init
        if perturb > 0:
            h = h + perturb * torch.randn_like(h)
        known = 1 - mask_lr
        for _ in range(iters):
            h = self.step(h, feat, 1 - known)
            # dilate the known region: reasoning proceeds boundary -> center
            known = F.max_pool2d(known, 3, stride=1, padding=1)
        return h


# ----------------------------- prior map head -----------------------------

class PriorMapHead(nn.Module):
    """128ch @32 -> 1ch @256 structural prior map in [-1,1]."""

    def __init__(self, dim=FEAT_CH):
        super().__init__()
        self.net = nn.Sequential(
            ConvBlock(dim, 64),
            nn.Upsample(scale_factor=2, mode="nearest"), ConvBlock(64, 64),
            nn.Upsample(scale_factor=2, mode="nearest"), ConvBlock(64, 32),
            nn.Upsample(scale_factor=2, mode="nearest"), ConvBlock(32, 16),
            nn.Conv2d(16, 1, 3, 1, 1),
        )

    def forward(self, feat):
        return torch.tanh(self.net(feat))


# ----------------------------- full prior network -----------------------------

class StructuralPriorNet(nn.Module):
    """SFA -> RFR -> prior map. Produces the 4th diffusion conditioning
    channel + exposes knobs (iters, perturb) for the feedback loop."""

    def __init__(self):
        super().__init__()
        self.encoder = FeatureEncoder()
        self.sfa = StructuralFusionAttention()
        self.rfr = RecurrentFeatureReasoning()
        self.head = PriorMapHead()

    def forward(self, damaged, mask, rfr_iters=4, perturb=0.0):
        feat = self.encoder(damaged, mask)
        feat = self.sfa(feat)
        mask_lr = F.interpolate(mask, size=(FEAT_RES, FEAT_RES), mode="nearest")
        feat = self.rfr(feat, mask_lr, iters=rfr_iters, perturb=perturb)
        return self.head(feat)           # (B,1,256,256) in [-1,1]


if __name__ == "__main__":
    net = StructuralPriorNet()
    print(f"prior net params: {sum(p.numel() for p in net.parameters())/1e6:.2f}M")
    d = torch.randn(2, 1, 256, 256)
    m = torch.zeros(2, 1, 256, 256); m[:, :, 80:160, 80:160] = 1
    p = net(d, m)
    print("prior map:", tuple(p.shape), float(p.min()), float(p.max()))
