"""
Stage 1 - Damage Detector: predicts the damage mask from the damaged
barcode alone. Trained on the same synthetic stream as the diffusion
model (data.py yields the ground-truth mask for free).

Model: ~2M param U-Net, 1ch in -> 1ch mask logits.
Loss : BCE + Dice.

train  : python damage_detector.py train --steps 50000
predict: from damage_detector import DamageUNet, predict_mask
"""

import argparse
import os

import cv2
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader

from data import DamagedBarcodes, MixedBarcodes


# ----------------------------- model -----------------------------

class DoubleConv(nn.Module):
    def __init__(self, cin, cout):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(cin, cout, 3, 1, 1), nn.GroupNorm(8, cout), nn.SiLU(),
            nn.Conv2d(cout, cout, 3, 1, 1), nn.GroupNorm(8, cout), nn.SiLU(),
        )

    def forward(self, x):
        return self.net(x)


class DamageUNet(nn.Module):
    """1ch damaged image -> 1ch mask logits (256x256)."""

    def __init__(self, ch=(32, 64, 128, 256)):
        super().__init__()
        self.enc = nn.ModuleList()
        cin = 1
        for c in ch:
            self.enc.append(DoubleConv(cin, c))
            cin = c
        self.pool = nn.MaxPool2d(2)
        self.dec = nn.ModuleList()
        for i in range(len(ch) - 1, 0, -1):
            self.dec.append(nn.ModuleDict({
                "up": nn.ConvTranspose2d(ch[i], ch[i - 1], 2, 2),
                "conv": DoubleConv(ch[i - 1] * 2, ch[i - 1]),
            }))
        self.head = nn.Conv2d(ch[0], 1, 1)

    def forward(self, x):
        skips = []
        for i, block in enumerate(self.enc):
            x = block(x)
            if i < len(self.enc) - 1:
                skips.append(x)
                x = self.pool(x)
        for block in self.dec:
            x = block["up"](x)
            x = block["conv"](torch.cat([x, skips.pop()], dim=1))
        return self.head(x)          # logits


# ----------------------------- training -----------------------------

def dice_loss(logits, target, eps=1.0):
    p = torch.sigmoid(logits)
    num = 2 * (p * target).sum(dim=(1, 2, 3)) + eps
    den = p.sum(dim=(1, 2, 3)) + target.sum(dim=(1, 2, 3)) + eps
    return (1 - num / den).mean()


def train(args):
    device = "cuda" if torch.cuda.is_available() else "cpu"
    os.makedirs(args.out, exist_ok=True)
    model = DamageUNet().to(device)
    print(f"detector params: {sum(p.numel() for p in model.parameters())/1e6:.2f}M")
    opt = torch.optim.AdamW(model.parameters(), lr=3e-4, weight_decay=1e-4)
    ds = (MixedBarcodes(args.real_dir, args.real_frac)
          if args.real_dir else DamagedBarcodes())
    dl = DataLoader(ds, batch_size=args.batch,
                    num_workers=args.workers, pin_memory=True)

    model.train()
    step = 0
    for batch in dl:
        damaged = batch["damaged"].to(device)
        mask = batch["mask"].to(device)
        logits = model(damaged)
        loss = F.binary_cross_entropy_with_logits(logits, mask) \
            + dice_loss(logits, mask)

        opt.zero_grad(set_to_none=True)
        loss.backward()
        opt.step()

        if step % 100 == 0:
            with torch.no_grad():
                iou = (( (torch.sigmoid(logits) > 0.5) & (mask > 0.5)).sum()
                       / (((torch.sigmoid(logits) > 0.5) | (mask > 0.5)).sum() + 1)).item()
            print(f"step {step:>6d}  loss {loss.item():.4f}  IoU {iou:.3f}")
        if step % args.save_every == 0 and step > 0:
            torch.save(model.state_dict(), os.path.join(args.out, "detector.pt"))
        step += 1
        if step >= args.steps:
            break

    torch.save(model.state_dict(), os.path.join(args.out, "detector.pt"))
    print("done ->", os.path.join(args.out, "detector.pt"))


# ----------------------------- inference -----------------------------

@torch.no_grad()
def predict_mask(model, damaged_uint8, device="cuda", thresh=0.5, dilate=5):
    """damaged uint8 (256,256) -> binary mask uint8 {0,1}.
    Mask is dilated a little: over-masking is safe (diffusion refills it),
    under-masking leaves damage in the 'trusted' region - never do that."""
    x = (torch.from_numpy(damaged_uint8.astype(np.float32) / 127.5 - 1.0)
         .unsqueeze(0).unsqueeze(0).to(device))
    prob = torch.sigmoid(model(x)).squeeze().cpu().numpy()
    m = (prob > thresh).astype(np.uint8)
    if dilate > 0:
        m = cv2.dilate(m, np.ones((dilate, dilate), np.uint8))
    return m


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    tr = sub.add_parser("train")
    tr.add_argument("--steps", type=int, default=20_000)
    tr.add_argument("--real_dir", type=str, default=None)
    tr.add_argument("--real_frac", type=float, default=0.5)
    tr.add_argument("--batch", type=int, default=64)
    tr.add_argument("--workers", type=int, default=8)
    tr.add_argument("--save_every", type=int, default=5_000)
    tr.add_argument("--out", default="ckpt")
    pr = sub.add_parser("predict")
    pr.add_argument("--ckpt", required=True)
    pr.add_argument("--image", required=True)
    pr.add_argument("--out", default="mask.png")
    args = ap.parse_args()

    if args.cmd == "train":
        train(args)
    else:
        device = "cuda" if torch.cuda.is_available() else "cpu"
        model = DamageUNet().to(device).eval()
        model.load_state_dict(torch.load(args.ckpt, map_location=device))
        img = cv2.imread(args.image, cv2.IMREAD_GRAYSCALE)
        img = cv2.resize(img, (256, 256), interpolation=cv2.INTER_AREA)
        m = predict_mask(model, img, device=device)
        cv2.imwrite(args.out, m * 255)
        print(f"mask saved -> {args.out}  (damage fraction {m.mean():.2%})")


if __name__ == "__main__":
    main()
