# Figure placeholders — drop images here and swap \framebox for \includegraphics

fig1_pipeline.pdf      Full pipeline diagram (teaser, full width)
fig2_dataset.png       Clean / degraded / mask triplet grid
fig3_architecture.pdf  Prior network (Track A) / ControlNet branch (Track B)
fig4_curve.pdf         Decode success vs damage fraction + RS capacity lines
fig5_qualitative.png   Step-by-step viz frames from pipeline.py viz/ output
fig6_rag.pdf           Hybrid RAG enterprise architecture

Swap pattern in main.tex:
  \framebox[...]{...}   -->   \includegraphics[width=\columnwidth]{figures/figX_name}
