# VESPER on-device PoC (Android)

End-to-end test harness for the VESPER skill-routing pipeline, runnable **on a phone/emulator**.
Mock backends by default so the whole loop is green with **zero models / no GPU**; every heavy
component is behind an interface you swap for your real working code.

## The loop (one screen of code, `VesperPipeline.kt`)
```
query + UI screenshot
  → multimodal embed (shared text/image space)
  → hybrid retrieve: vector (HNSW) + BM25 → RRF fuse (k=60)
  → pick SKILL.md → SLM lowers steps → ExecutionPlan
  → UI executes → Validator checks end-state
  → on FAIL: validator feedback re-grounds the next retrieval round
            (execution-grounded re-retrieval), up to maxRounds
```

## Run it

Interactive app:
```
./gradlew installDebug      # tap the button, watch the trace (incl. re-retrieval round)
```

The actual on-device test (this is your patent evidence):
```
./gradlew connectedDebugAndroidTest
# logcat tag VESPER prints the full per-round trace
```

Three tests in `VesperEndToEndTest`:
- `skills_load_from_assets` — SKILL.md corpus parses (screenshots + steps)
- `full_pipeline_succeeds_first_try` — clean path, 1 retrieval round
- `execution_grounded_re_retrieval_recovers` — failure → re-grounded retrieval → recovery

## Swapping mocks for real on-device models

| Component | Mock (default) | Real on-device (drop-in) |
|---|---|---|
| Embedder | `MockEmbedder` (hashing) | `OnDeviceEmbedder` → ONNX Runtime. **Qwen2-VL** for joint text+image, or lightweight **EmbeddingGemma-300M (text) + MobileCLIP2-S2 / Nomic-vision (image)** in a shared space |
| Vector index | `InMemoryVectorIndex` (brute cosine) | **ObjectBox** `@HnswIndex` float[] + `nearestNeighbors()` |
| Sparse | `Bm25Index` (in-proc) | same, or SQLite FTS5 |
| SLM | `MockSlm` | `LlamaCppExecutor` → **Gemma 4 E2B-it GGUF** via your llama.cpp JNI (use Q5_K_M + imatrix; Q4_K_M looped) |
| UI executor | `MockUiExecutor` | AccessibilityService actions + screenshot capture |
| Validator | `MockValidator` | `VlValidator` → VL screenshot diff / VL-judge (Qwen-VL) |

Toggle `BuildConfig.VESPER_REAL_BACKENDS` and pass real impls into `Vesper.build(...)`.

## Honest constraints
- Qwen-VL embedder **and** Gemma SLM resident together is heavy (multi-GB). For a phone test,
  prefer the lightweight embedder pair and load the SLM lazily; reserve Qwen-VL for high-end
  devices or a server tier. The architecture doesn't change either way.
- The in-memory vector index is O(N); fine for a PoC corpus, replace with ObjectBox HNSW for scale.
