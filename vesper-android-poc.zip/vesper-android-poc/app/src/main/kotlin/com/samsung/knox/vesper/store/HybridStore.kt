package com.samsung.knox.vesper.store

import com.samsung.knox.vesper.Scored
import kotlin.math.ln

/** Dense side. InMemory default runs anywhere; swap for ObjectBox HNSW on real builds. */
interface VectorIndex {
    fun add(id: String, vec: FloatArray)
    fun search(query: FloatArray, k: Int): List<Scored<String>>   // returns skill ids
}

/** Brute-force cosine. Fine for a PoC corpus; O(N) but N is tiny here. */
class InMemoryVectorIndex : VectorIndex {
    private val store = LinkedHashMap<String, FloatArray>()
    override fun add(id: String, vec: FloatArray) { store[id] = vec }
    override fun search(query: FloatArray, k: Int): List<Scored<String>> =
        store.entries.map { Scored(it.key, cosine(query, it.value)) }
            .sortedByDescending { it.score }
            .take(k)
    private fun cosine(a: FloatArray, b: FloatArray): Double {
        var dot = 0.0; var na = 0.0; var nb = 0.0
        for (i in a.indices) { dot += a[i]*b[i]; na += a[i]*a[i]; nb += b[i]*b[i] }
        return if (na == 0.0 || nb == 0.0) 0.0 else dot / (Math.sqrt(na)*Math.sqrt(nb))
    }
}

/**
 * REAL: ObjectBox HNSW. Define an entity with an @HnswIndex float[] property and
 * query with nearestNeighbors(queryVec, k). Implement VectorIndex over that box.
 *
 *   class SkillVec { @Id var dbId=0L; @Index var skillId=""; @HnswIndex(dimensions=768) var vec=FloatArray(0) }
 *   box.query(SkillVec_.vec.nearestNeighbors(q, k)).build().findWithScores()
 */

/** Sparse side: minimal BM25 over skill descriptions/keywords. */
class Bm25Index(private val k1: Double = 1.5, private val b: Double = 0.75) {
    private val docs = LinkedHashMap<String, List<String>>()
    private val df = HashMap<String, Int>()
    private var avgdl = 0.0

    fun add(id: String, text: String) {
        val toks = tokenize(text)
        docs[id] = toks
        toks.toSet().forEach { df[it] = (df[it] ?: 0) + 1 }
        avgdl = docs.values.sumOf { it.size }.toDouble() / docs.size
    }

    fun search(query: String, k: Int): List<Scored<String>> {
        val q = tokenize(query)
        val n = docs.size.toDouble()
        return docs.entries.map { (id, toks) ->
            val tf = HashMap<String, Int>()
            toks.forEach { tf[it] = (tf[it] ?: 0) + 1 }
            var score = 0.0
            for (term in q) {
                val f = tf[term] ?: continue
                val idf = ln(1 + (n - (df[term] ?: 0) + 0.5) / ((df[term] ?: 0) + 0.5))
                val denom = f + k1 * (1 - b + b * toks.size / avgdl)
                score += idf * (f * (k1 + 1)) / denom
            }
            Scored(id, score)
        }.filter { it.score > 0 }.sortedByDescending { it.score }.take(k)
    }

    private fun tokenize(s: String) =
        s.lowercase().split(Regex("\\W+")).filter { it.isNotBlank() }
}

/** Reciprocal Rank Fusion — same k=60 you use in DynamicRAG2. */
object Rrf {
    fun fuse(vararg ranked: List<Scored<String>>, k: Int = 60): List<Scored<String>> {
        val acc = HashMap<String, Double>()
        for (list in ranked) {
            list.forEachIndexed { rank, hit ->
                acc[hit.item] = (acc[hit.item] ?: 0.0) + 1.0 / (k + rank + 1)
            }
        }
        return acc.entries.map { Scored(it.key, it.value) }.sortedByDescending { it.score }
    }
}

/** Facade combining dense + sparse + RRF. */
class HybridStore(
    private val vectors: VectorIndex = InMemoryVectorIndex(),
    private val bm25: Bm25Index = Bm25Index(),
) {
    fun index(id: String, text: String, vec: FloatArray) {
        vectors.add(id, vec); bm25.add(id, text)
    }
    fun retrieve(queryVec: FloatArray, queryText: String, k: Int = 5): List<Scored<String>> {
        val dense = vectors.search(queryVec, k * 2)
        val sparse = bm25.search(queryText, k * 2)
        return Rrf.fuse(dense, sparse).take(k)
    }
}
