package com.samsung.knox.vesper.skill

import android.content.Context
import com.samsung.knox.vesper.Skill

/**
 * Loads SKILL.md files from assets/skills/. Minimal front-matter-ish parser:
 *   # Title
 *   description: ...
 *   keywords: a, b, c
 *   screenshot: skills/wifi.png
 *   ## Steps
 *   1. ...
 *   2. ...
 */
class SkillRepository(private val context: Context) {

    fun loadAll(dir: String = "skills"): List<Skill> {
        val am = context.assets
        return (am.list(dir) ?: emptyArray())
            .filter { it.endsWith(".md") }
            .map { fname ->
                val raw = am.open("$dir/$fname").bufferedReader().use { it.readText() }
                parse(fname.removeSuffix(".md"), raw)
            }
    }

    fun parse(id: String, md: String): Skill {
        var title = id
        var description = ""
        var screenshot: String? = null
        val keywords = mutableListOf<String>()
        val steps = mutableListOf<String>()
        var inSteps = false
        for (line in md.lineSequence()) {
            val t = line.trim()
            when {
                t.startsWith("# ") && title == id -> title = t.removePrefix("# ").trim()
                t.startsWith("## steps", true) -> inSteps = true
                t.startsWith("description:", true) ->
                    description = t.substringAfter(":").trim()
                t.startsWith("screenshot:", true) ->
                    screenshot = t.substringAfter(":").trim()
                t.startsWith("keywords:", true) ->
                    keywords += t.substringAfter(":").split(",").map { it.trim() }.filter { it.isNotBlank() }
                inSteps && t.matches(Regex("^\\d+\\..*")) ->
                    steps += t.replaceFirst(Regex("^\\d+\\.\\s*"), "")
            }
        }
        val indexedText = buildString {
            append(title); append(' '); append(description); append(' ')
            append(keywords.joinToString(" "))
        }.trim()
        return Skill(id, title, description.ifBlank { indexedText }, steps, screenshot, keywords)
    }
}
