package com.samsung.knox.vesper.ui

import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.samsung.knox.vesper.Vesper
import com.samsung.knox.vesper.VesperQuery

/**
 * Minimal interactive harness so you can run the loop on a real phone and watch
 * the trace (including the re-retrieval round) in-app. No layout XML needed.
 */
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val out = TextView(this).apply {
            movementMethod = ScrollingMovementMethod()
            textSize = 12f
            setPadding(24, 24, 24, 24)
        }
        val btn = Button(this).apply { text = "Run VESPER (query + UI screenshot)" }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.TOP
            addView(btn)
            addView(out)
        }
        setContentView(root)

        btn.setOnClickListener {
            val (pipeline, skills) = Vesper.build(this)
            // Demo query that first mis-routes (mock UI fails on "Bluetooth"),
            // forcing the execution-grounded re-retrieval to recover.
            val fakeScreenshot = ByteArray(512) { (it % 7).toByte() }
            val trace = pipeline.run(
                VesperQuery(text = "turn off wireless radios to save battery", screenshot = fakeScreenshot)
            )
            out.text = buildString {
                appendLine("Skills indexed: ${skills.size}")
                appendLine("Retrieval rounds: ${trace.retrievalRounds}")
                appendLine("Chosen skill: ${trace.chosenSkill?.title}")
                appendLine("Validation: ${trace.validation?.passed} (${trace.validation?.reason})")
                appendLine("\n--- trace ---")
                trace.log.forEach { appendLine("• $it") }
            }
        }
    }
}
