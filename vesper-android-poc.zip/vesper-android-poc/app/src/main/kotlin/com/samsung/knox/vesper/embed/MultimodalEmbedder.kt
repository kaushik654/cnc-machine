package com.samsung.knox.vesper.embed

import com.samsung.knox.vesper.VesperQuery
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Fuses (query text + UI screenshot) into one vector in a shared space.
 * Patent-relevant: the *combined* multimodal key is what the store is indexed on,
 * so retrieval is conditioned jointly on intent (text) and on-screen context (image).
 */
interface MultimodalEmbedder {
    val dim: Int
    fun embedQuery(q: VesperQuery): FloatArray
    fun embedSkillText(text: String): FloatArray   // documents are text-side of the same space
}

fun l2norm(v: FloatArray): FloatArray {
    var s = 0.0
    for (x in v) s += (x * x).toDouble()
    val n = sqrt(s).toFloat().coerceAtLeast(1e-9f)
    return FloatArray(v.size) { v[it] / n }
}

/**
 * Deterministic mock: hashes tokens into a fixed-dim vector and folds in a cheap
 * image signature. Runs anywhere, no models. Good enough to exercise the full
 * control flow and to keep instrumented tests green on a bare emulator.
 */
class MockEmbedder(override val dim: Int = 256) : MultimodalEmbedder {

    private fun textVec(text: String): FloatArray {
        val v = FloatArray(dim)
        for (tok in text.lowercase().split(Regex("\\W+")).filter { it.isNotBlank() }) {
            val h = tok.hashCode()
            val r = Random(h.toLong())
            for (i in 0 until dim) v[i] += (r.nextFloat() - 0.5f)
        }
        return v
    }

    private fun imageVec(bytes: ByteArray?): FloatArray {
        val v = FloatArray(dim)
        if (bytes == null || bytes.isEmpty()) return v
        // Cheap perceptual signature: bucketed byte histogram projected into dim.
        val hist = IntArray(256)
        for (b in bytes) hist[b.toInt() and 0xFF]++
        for (i in 0 until 256) v[i % dim] += hist[i].toFloat()
        return v
    }

    override fun embedQuery(q: VesperQuery): FloatArray {
        val t = textVec(q.text)
        val im = imageVec(q.screenshot)
        return l2norm(FloatArray(dim) { 0.7f * t[it] + 0.3f * im[it] })
    }

    override fun embedSkillText(text: String): FloatArray = l2norm(textVec(text))
}

/**
 * Real on-device path. Two clean options discussed for your stack:
 *
 *  A) Qwen2-VL embedder (your stated choice) — runs the VL encoder to embed the
 *     interleaved [text + screenshot] in one pass. Heaviest; needs a high-end device
 *     or the GGUF/ONNX export wired through your llama.cpp/ORT bridge.
 *
 *  B) Lightweight shared-space pair (recommended for true on-device):
 *     text  -> EmbeddingGemma-300M (ONNX)  OR  Nomic-embed-text-v1.5
 *     image -> MobileCLIP2-S2 / Nomic-embed-vision-v1.5 (ONNX, aligned space)
 *     Fuse by concatenation+reproject, or use Nomic's already-shared space directly.
 *
 * Drop your ONNX Runtime sessions in here; the rest of the pipeline is unchanged.
 */
class OnDeviceEmbedder(
    override val dim: Int = 768,
    // ortTextSession: OrtSession,
    // ortVisionSession: OrtSession,
) : MultimodalEmbedder {
    override fun embedQuery(q: VesperQuery): FloatArray =
        throw NotImplementedError("Wire ONNX Runtime sessions (Qwen-VL or EmbeddingGemma+MobileCLIP) here")
    override fun embedSkillText(text: String): FloatArray =
        throw NotImplementedError("Wire ONNX Runtime text session here")
}
