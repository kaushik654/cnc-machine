package com.samsung.knox.vesper.slm

import com.samsung.knox.vesper.ExecutionPlan
import com.samsung.knox.vesper.Skill
import com.samsung.knox.vesper.VesperQuery

/**
 * Turns a retrieved skill + the live query into a concrete ExecutionPlan.
 * Real impl: Gemma 4 E2B-it (or similar <=4B) via llama.cpp JNI / LiteRT-LM.
 */
interface SlmExecutor {
    fun plan(query: VesperQuery, skill: Skill, feedback: String? = null): ExecutionPlan
}

/**
 * Mock planner: deterministically lowers skill.steps into actions and, if the
 * validator passed feedback (re-retrieval round), prepends a corrective action.
 * No model required.
 */
class MockSlm : SlmExecutor {
    override fun plan(query: VesperQuery, skill: Skill, feedback: String?): ExecutionPlan {
        val actions = buildList {
            if (feedback != null) add("RECOVER: adjust for -> $feedback")
            skill.steps.forEach { add("DO: $it") }
        }
        return ExecutionPlan(
            skillId = skill.id,
            actions = actions,
            rationale = "Selected '${skill.title}' for query='${query.text}'" +
                if (feedback != null) " (re-planned after validator feedback)" else "",
        )
    }
}

/**
 * REAL: Gemma 4 E2B-it via your existing llama.cpp JNI bridge.
 * Build a prompt from skill.steps + query (+ optional screenshot caption / feedback),
 * call native generate(), parse the JSON action list.
 *
 *   external fun nativeGenerate(ctxPtr: Long, prompt: String, maxTokens: Int): String
 *
 * Remember the Q5_K_M + imatrix lesson — Q4_K_M degraded into token loops for Gemma 4.
 */
class LlamaCppExecutor(private val ctxPtr: Long) : SlmExecutor {
    override fun plan(query: VesperQuery, skill: Skill, feedback: String?): ExecutionPlan =
        throw NotImplementedError("Wire llama.cpp JNI generate() + JSON parse here")

    companion object { init { /* System.loadLibrary("llama-android") */ } }
}
