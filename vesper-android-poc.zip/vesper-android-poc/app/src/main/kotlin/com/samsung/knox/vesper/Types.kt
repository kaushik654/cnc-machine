package com.samsung.knox.vesper

/** A user request: natural-language text plus the current UI screenshot (as raw bytes). */
data class VesperQuery(
    val text: String,
    val screenshot: ByteArray?,        // PNG/JPEG bytes; null = text-only
)

/** One retrievable skill, parsed from a SKILL.md file. */
data class Skill(
    val id: String,
    val title: String,
    val description: String,           // indexed for retrieval
    val steps: List<String>,           // ordered actions the executor will run
    val screenshotRef: String? = null, // asset/file path of the reference UI
    val keywords: List<String> = emptyList(),
)

/** A scored retrieval hit. */
data class Scored<T>(val item: T, val score: Double)

/** What the SLM turns retrieved steps into: concrete, ordered executable actions. */
data class ExecutionPlan(
    val skillId: String,
    val actions: List<String>,
    val rationale: String,
)

/** Validator verdict comparing post-execution UI against the expected end-state. */
data class ValidationResult(
    val passed: Boolean,
    val confidence: Double,
    val reason: String,
)

/** Full end-to-end trace — this is the artifact your patent test asserts on. */
data class VesperTrace(
    val query: VesperQuery,
    val retrievalRounds: Int,          // >1 proves execution-grounded re-retrieval fired
    val chosenSkill: Skill?,
    val plan: ExecutionPlan?,
    val validation: ValidationResult?,
    val log: List<String>,
)
