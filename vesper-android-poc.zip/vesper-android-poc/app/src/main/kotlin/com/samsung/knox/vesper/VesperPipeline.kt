package com.samsung.knox.vesper

import com.samsung.knox.vesper.embed.MultimodalEmbedder
import com.samsung.knox.vesper.store.HybridStore
import com.samsung.knox.vesper.slm.SlmExecutor
import com.samsung.knox.vesper.validate.UiExecutor
import com.samsung.knox.vesper.validate.Validator

/**
 * VESPER end-to-end orchestrator.
 *
 *   query+screenshot --(multimodal embed)--> hybrid retrieve (HNSW + BM25 + RRF)
 *     --> pick skill --> SLM lowers steps to ExecutionPlan --> UI executes
 *     --> Validator checks end-state.
 *   On FAIL: validator feedback re-grounds the next retrieval/plan round
 *            (execution-grounded re-retrieval) up to maxRounds.
 */
class VesperPipeline(
    private val embedder: MultimodalEmbedder,
    private val store: HybridStore,
    private val skillsById: Map<String, Skill>,
    private val slm: SlmExecutor,
    private val ui: UiExecutor,
    private val validator: Validator,
    private val maxRounds: Int = 3,
) {

    /** One-time indexing of the skill corpus into the hybrid store. */
    fun indexSkills(skills: Collection<Skill>) {
        for (s in skills) {
            val text = "${s.title} ${s.description} ${s.keywords.joinToString(" ")}"
            store.index(s.id, text, embedder.embedSkillText(text))
        }
    }

    fun run(query: VesperQuery): VesperTrace {
        val log = mutableListOf<String>()
        val qVec = embedder.embedQuery(query)
        log += "embedded query (dim=${embedder.dim}, hasImage=${query.screenshot != null})"

        var feedback: String? = null
        var chosen: Skill? = null
        var plan: ExecutionPlan? = null
        var verdict: ValidationResult? = null
        var round = 0
        val excluded = mutableSetOf<String>()

        while (round < maxRounds) {
            round++
            // Re-retrieval is grounded by validator feedback: failed skill is demoted.
            val hits = store.retrieve(qVec, query.text + (feedback?.let { " $it" } ?: ""), k = 5)
                .filter { it.item !in excluded }
            log += "round $round retrieval: ${hits.joinToString { "%s(%.3f)".format(it.item, it.score) }}"
            chosen = hits.firstOrNull()?.let { skillsById[it.item] }
            if (chosen == null) { log += "no skill retrieved"; break }

            plan = slm.plan(query, chosen, feedback)
            log += "plan[${chosen.id}]: ${plan.actions}"

            val state = ui.run(plan)
            log += "ui state: $state"

            verdict = validator.validate(plan, state)
            log += "validate: passed=${verdict.passed} conf=%.2f (%s)".format(verdict.confidence, verdict.reason)

            if (verdict.passed) break
            // Ground the next round in the observed failure.
            feedback = verdict.reason
            excluded += chosen.id
            log += "re-retrieving, grounded on failure: \"$feedback\""
        }

        return VesperTrace(query, round, chosen, plan, verdict, log)
    }
}
