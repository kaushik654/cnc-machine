package com.samsung.knox.vesper.validate

import com.samsung.knox.vesper.ExecutionPlan
import com.samsung.knox.vesper.ValidationResult

/**
 * Executes an ExecutionPlan against the (simulated) device UI and returns the
 * resulting screen state. In a real build this drives Accessibility actions and
 * captures a post-action screenshot.
 */
interface UiExecutor {
    /** @return a description/signature of the resulting UI state. */
    fun run(plan: ExecutionPlan): String
}

/**
 * Mock UI: succeeds unless the plan targets a skill whose steps mention a token
 * we deliberately "fail" once, to force a re-retrieval round in tests.
 */
class MockUiExecutor(private val failOnce: String? = null) : UiExecutor {
    private var failed = false
    override fun run(plan: ExecutionPlan): String {
        if (failOnce != null && !failed &&
            plan.actions.any { it.contains(failOnce, true) }) {
            failed = true
            return "STATE: error_dialog(reason=$failOnce)"
        }
        return "STATE: ok(${plan.skillId})"
    }
}

/**
 * Validator agent. Compares achieved UI state against the skill's expected
 * end-state. Real impl: a VL model (Qwen-VL / a small captioner) diffs the
 * post-action screenshot vs the skill's reference screenshot.
 *
 * The patent's core loop: on FAIL, it emits structured feedback that re-grounds
 * the next retrieval round (execution-grounded re-retrieval).
 */
interface Validator {
    fun validate(plan: ExecutionPlan, achievedState: String): ValidationResult
}

class MockValidator : Validator {
    override fun validate(plan: ExecutionPlan, achievedState: String): ValidationResult {
        val ok = achievedState.startsWith("STATE: ok")
        return ValidationResult(
            passed = ok,
            confidence = if (ok) 0.95 else 0.2,
            reason = if (ok) "End-state matches expected for ${plan.skillId}"
                     else achievedState.substringAfter("reason=").substringBefore(")"),
        )
    }
}

/**
 * REAL: VL validator. Caption/encode the post-action screenshot, compare to the
 * skill's reference screenshot embedding (cosine) AND/OR ask a VL SLM
 * "did the action achieve <goal>? answer PASS/FAIL + reason".
 */
class VlValidator : Validator {
    override fun validate(plan: ExecutionPlan, achievedState: String): ValidationResult =
        throw NotImplementedError("Wire VL screenshot diff / VL-judge here")
}
