package com.samsung.knox.vesper

import android.content.Context
import com.samsung.knox.vesper.embed.MockEmbedder
import com.samsung.knox.vesper.embed.MultimodalEmbedder
import com.samsung.knox.vesper.skill.SkillRepository
import com.samsung.knox.vesper.slm.MockSlm
import com.samsung.knox.vesper.slm.SlmExecutor
import com.samsung.knox.vesper.store.HybridStore
import com.samsung.knox.vesper.validate.MockUiExecutor
import com.samsung.knox.vesper.validate.MockValidator
import com.samsung.knox.vesper.validate.UiExecutor
import com.samsung.knox.vesper.validate.Validator

/** Wires the pipeline. Swap the mock components for real ones behind these factories. */
object Vesper {

    fun build(
        context: Context,
        embedder: MultimodalEmbedder = MockEmbedder(),
        slm: SlmExecutor = MockSlm(),
        ui: UiExecutor = MockUiExecutor(failOnce = "Bluetooth"), // forces a re-retrieval demo
        validator: Validator = MockValidator(),
    ): Pair<VesperPipeline, List<Skill>> {
        val skills = SkillRepository(context).loadAll()
        val byId = skills.associateBy { it.id }
        val pipeline = VesperPipeline(
            embedder = embedder,
            store = HybridStore(),
            skillsById = byId,
            slm = slm,
            ui = ui,
            validator = validator,
        )
        pipeline.indexSkills(skills)
        return pipeline to skills
    }
}
