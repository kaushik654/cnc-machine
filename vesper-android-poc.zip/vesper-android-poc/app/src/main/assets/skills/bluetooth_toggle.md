# Toggle Bluetooth
description: turn bluetooth wireless radio on or off to save battery or disconnect devices
keywords: bluetooth, wireless, radio, battery, pairing, devices
screenshot: skills/bluetooth_toggle.png
## Steps
1. Open Settings
2. Tap Connections
3. Tap Bluetooth
4. Toggle the Bluetooth switch off
