# Toggle Wi-Fi
description: turn wifi wireless network radio on or off to save battery or go offline
keywords: wifi, wireless, network, radio, battery, offline, internet
screenshot: skills/wifi_toggle.png
## Steps
1. Open Settings
2. Tap Connections
3. Tap Wi-Fi
4. Toggle the Wi-Fi switch off
