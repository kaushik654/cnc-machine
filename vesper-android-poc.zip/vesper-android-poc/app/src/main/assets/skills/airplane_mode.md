# Enable Airplane Mode
description: enable airplane flight mode to turn off all wireless radios at once to save battery
keywords: airplane, flight, wireless, radios, battery, offline, all
screenshot: skills/airplane_mode.png
## Steps
1. Open quick settings panel
2. Tap the Airplane mode tile
3. Confirm all radios are disabled
