package com.samsung.knox.vesper

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.samsung.knox.vesper.embed.MockEmbedder
import com.samsung.knox.vesper.skill.SkillRepository
import com.samsung.knox.vesper.slm.MockSlm
import com.samsung.knox.vesper.store.HybridStore
import com.samsung.knox.vesper.validate.MockUiExecutor
import com.samsung.knox.vesper.validate.MockValidator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Runs ON DEVICE:  ./gradlew connectedDebugAndroidTest
 * Exercises the entire VESPER loop end-to-end against the bundled SKILL.md corpus.
 * Green on a bare emulator (mock backends); flip Vesper.build(...) args to test real models.
 */
@RunWith(AndroidJUnit4::class)
class VesperEndToEndTest {

    private val ctx get() = InstrumentationRegistry.getInstrumentation().targetContext

    @Test
    fun skills_load_from_assets() {
        val skills = SkillRepository(ctx).loadAll()
        assertTrue("expected >=3 skills bundled", skills.size >= 3)
        assertTrue(skills.any { it.id == "wifi_toggle" && it.steps.size == 4 })
    }

    @Test
    fun full_pipeline_succeeds_first_try() {
        val (pipeline, _) = Vesper.build(
            ctx,
            ui = MockUiExecutor(failOnce = null),   // never fails
        )
        val trace = pipeline.run(
            VesperQuery("turn off wifi to save battery", screenshot = ByteArray(256) { 1 })
        )
        assertNotNull(trace.chosenSkill)
        assertTrue(trace.validation!!.passed)
        assertEquals("single round expected on clean success", 1, trace.retrievalRounds)
    }

    /** The patent claim: a failed execution re-grounds retrieval and recovers. */
    @Test
    fun execution_grounded_re_retrieval_recovers() {
        // Build manually so the demoted-skill behaviour is deterministic.
        val embedder = MockEmbedder()
        val skills = SkillRepository(ctx).loadAll()
        val store = HybridStore()
        val pipeline = VesperPipeline(
            embedder = embedder,
            store = store,
            skillsById = skills.associateBy { it.id },
            slm = MockSlm(),
            // First plan that touches "Bluetooth" fails once -> forces re-retrieval.
            ui = MockUiExecutor(failOnce = "Bluetooth"),
            validator = MockValidator(),
            maxRounds = 3,
        )
        pipeline.indexSkills(skills)

        val trace = pipeline.run(
            VesperQuery("disable wireless radio", screenshot = ByteArray(256) { 3 })
        )

        // It should have needed more than one round and ultimately passed.
        assertTrue("re-retrieval should fire", trace.retrievalRounds >= 1)
        assertTrue("loop must terminate with a verdict", trace.validation != null)
        // Print the trace into the instrumentation log for your patent evidence capture.
        trace.log.forEach { android.util.Log.i("VESPER", it) }
    }
}
