plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    // --- REAL STORE: uncomment to enable ObjectBox HNSW vector index ---
    // id("io.objectbox") version "4.0.2"
}

android {
    namespace = "com.samsung.knox.vesper"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.samsung.knox.vesper"
        minSdk = 28
        targetSdk = 34
        versionCode = 1
        versionName = "0.1-poc"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        // Flip this to run against real on-device models instead of mocks.
        // Read in code via BuildConfig.VESPER_REAL_BACKENDS.
        buildConfigField("boolean", "VESPER_REAL_BACKENDS", "false")
    }

    buildFeatures { buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // --- REAL EMBEDDER (image+text): ONNX Runtime for MobileCLIP2 / Nomic / EmbeddingGemma ---
    // implementation("com.microsoft.onnxruntime:onnxruntime-android:1.18.0")

    // --- REAL STORE: ObjectBox runtime (paired with the plugin above) ---
    // implementation("io.objectbox:objectbox-android:4.0.2")

    // --- REAL SLM: your llama.cpp JNI .aar (Gemma 4 E2B-it GGUF) ---
    // implementation(files("libs/llama-android.aar"))

    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test:runner:1.6.1")
    androidTestImplementation("androidx.test:rules:1.6.1")
    androidTestImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.8.1")
}
